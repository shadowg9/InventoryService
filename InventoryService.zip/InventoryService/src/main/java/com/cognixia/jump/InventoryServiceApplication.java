package com.cognixia.jump;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryServiceApplication.class, args);
	}

}


//Afternoon Exercise:
//___________________________
//
//You are going to create a OrderService (Producer) project that will manages data for an Orders Table. A singular order will store an id, date of purchase, item purchased, quantity of the item purchased. 
//
//You will also create an InventoryService (Consumer) that will manage data for an Inventory table. This items table will contain id, name of item, unit price, and quanity available.
//
//Using Kafka, every time a new order is created, send a message to the inventory service to update the quanity for the item. As well, make sure these services are microservices, so keep their databases seperated.
//
//
//TURN IN: Make sure once you have finished the exercise to turn in upload it to github and message the link to me over slack
