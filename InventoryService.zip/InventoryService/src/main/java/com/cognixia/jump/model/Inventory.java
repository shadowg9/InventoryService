package com.cognixia.jump.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity 
public class Inventory implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column 
	private String item_name;
	
	@Column
	private double unit_price;
	
	@Column
	private int available_quantity;
	
	public Inventory() {
		
	}

	public Inventory(Long id, String item_name, double unit_price, int available_quantity) {
		super();
		this.id = id;
		this.item_name = item_name;
		this.unit_price = unit_price;
		this.available_quantity = available_quantity;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(double unit_price) {
		this.unit_price = unit_price;
	}

	public int getAvailable_quantity() {
		return available_quantity;
	}

	public void setAvailable_quantity(int available_quantity) {
		this.available_quantity = available_quantity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Inventory [id=" + id + ", item_name=" + item_name + ", unit_price=" + unit_price
				+ ", available_quantity=" + available_quantity + "]";
	}
	
	
	
	

}
