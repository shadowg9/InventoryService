package com.cognixia.jump.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognixia.jump.model.Order;
import com.cognixia.jump.service.OrderService;


@RestController
@RequestMapping("/api/students")
public class OrderController {
	
	
	@Autowired 
	OrderService service;
	//("")
	@GetMapping("")
	public List<Order> getAllOrders(){
		return service.getAllOrders();
	}
	
	
	@RequestMapping(value = "/id/{id}", method = RequestMethod.GET)
	public Order getStudentById(@PathVariable String id) {
		
		return service.getOrderById(Integer.parseInt(id));
		
	}
	
	
	
	@PostMapping("/create")
	public ResponseEntity<?> createOrder(@RequestBody Order order){
		
		Order newOrder = service.addOrder(order);
		
		
		System.out.println("New order added: " + newOrder);
		

		
		return ResponseEntity.ok(newOrder + " created.");
		
		
	}
	
	//Update Student - all fields = Put, some fields = Patch
	@PutMapping("/update")
	public ResponseEntity<?> updateOrder(@RequestBody Order input){
		
		Order toUpdate = service.updateOrder(input);
		
		return ResponseEntity.ok(toUpdate + " updated.");
		
	}
	

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteOrder(@PathVariable int id){
		
		Order deleted = service.deleteOrder(id);
		
		return ResponseEntity.ok(deleted + " deleted.");
		
	}
	
}
