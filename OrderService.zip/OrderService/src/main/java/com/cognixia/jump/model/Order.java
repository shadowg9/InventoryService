package com.cognixia.jump.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Order implements Serializable {


	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column
	private String puchase_date;
	
	@Column
	private String item_purchased; 
	
	@Column
	private String quantity_purchased; 
	
	public Order() {
		
	}

	public Order(Long id, String puchase_date, String item_purchased, String quantity_purchased) {
		super();
		this.id = id;
		this.puchase_date = puchase_date;
		this.item_purchased = item_purchased;
		this.quantity_purchased = quantity_purchased;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPuchase_date() {
		return puchase_date;
	}

	public void setPuchase_date(String puchase_date) {
		this.puchase_date = puchase_date;
	}

	public String getItem_purchased() {
		return item_purchased;
	}

	public void setItem_purchased(String item_purchased) {
		this.item_purchased = item_purchased;
	}

	public String getQuantity_purchased() {
		return quantity_purchased;
	}

	public void setQuantity_purchased(String quantity_purchased) {
		this.quantity_purchased = quantity_purchased;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", puchase_date=" + puchase_date + ", item_purchased=" + item_purchased
				+ ", quantity_purchased=" + quantity_purchased + "]";
	}
	
	

}
