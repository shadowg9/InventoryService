package com.cognixia.jump.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.cognixia.jump.model.Message;
import com.cognixia.jump.model.Order;

@Service
public class OrderService {
	
	// help place our message onto a kafka topic
	@Autowired 
	private KafkaTemplate<String, Message> kafkaTemplate;
	
	public void produce(Message message) {
		
		System.out.println("Producing message: " + message);
		
		// first argument: topic
		// second argument: message to place on the topic 
		kafkaTemplate.send("messages", message);
		
	}

	public Order deleteOrder(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Order updateOrder(Order input) {
		// TODO Auto-generated method stub
		return null;
	}

	public Order addOrder(Order order) {
		// TODO Auto-generated method stub
		return null;
	}

	public Order getOrderById(int parseInt) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Order> getAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

}
